//
//  ThirdViewController.swift
//  Assigment-2
//
//  Created by admin on 30.01.2021.
//

import UIKit


class ThirdViewController: UIViewController{
   
    
    var ResultScore = 0
    override func viewDidLoad() {
        super.viewDidLoad()
     
        let percent = ResultScore * 100 / 5
        Score.text = "\(percent)%"
        if(percent <= 50){
            Result.text = "Try again"
        }else if(percent <= 80){
            Result.text = "Good result"
        }else{
            Result.text = "Excellent"
        }
        
    }
  
    @IBOutlet weak var Score: UILabel!
    
    @IBOutlet weak var Result: UILabel!
    
    @IBAction func Restart(_ sender: Any) {
        let vcR = storyboard?.instantiateViewController(identifier: "SecondViewController") as! SecondViewController
        navigationController?.pushViewController(vcR, animated: true)
        
    }
    @IBAction func Home(_ sender: Any) {
        let vcH = storyboard?.instantiateViewController(identifier: "ViewController") as! ViewController
        navigationController?.pushViewController(vcH, animated: true)    }
}



