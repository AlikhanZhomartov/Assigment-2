//
//  ViewController.swift
//  Assigment-2
//
//  Created by admin on 28.01.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func Start(_ sender: Any) {
        let start = storyboard?.instantiateViewController(identifier: "SecondViewController") as! SecondViewController
        navigationController?.pushViewController(start, animated: true)
    
    }
    

}

