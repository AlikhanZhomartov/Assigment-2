//
//  SecondViewController.swift
//  Assigment-2
//
//  Created by admin on 28.01.2021.
//

import UIKit

class SecondViewController: UIViewController {

    var index = 0;
    var score = 0;
    var Questions = [questions]()
 
    
    @IBOutlet weak var Question: UILabel!
    
    @IBOutlet weak var FirstOption: UIButton!
    
    @IBOutlet weak var SecondOption: UIButton!
    
    @IBOutlet weak var ThirdOption: UIButton!
    
    @IBOutlet weak var FourhOption: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        AppendArray()
        Question.text = Questions[0].question
        FirstOption.setTitle(Questions[0].firstOption, for: .normal)
        SecondOption.setTitle(Questions[0].secondOption, for: .normal)
        ThirdOption.setTitle(Questions[0].thirdOption, for: .normal)
        FourhOption.setTitle(Questions[0].fourthOption, for: .normal)
        
    }


    
    
    
    @IBAction func FirstOption(_ sender: UIButton) {
       if(sender.currentTitle == Questions[index].correct){
            sender.backgroundColor = .green
        Questions[index].answer = Questions[index].correct
        score = score + 1
        if(Questions[0].answer != "" && Questions[1].answer != "" && Questions[2].answer != "" && Questions[3].answer != "" &&
            Questions[4].answer != ""){
          
          let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let vc = storyboard.instantiateViewController(identifier: "ThirdViewController") as? ThirdViewController{
            vc.ResultScore = score
            show(vc, sender: nil)
            }
        }
       }else{
        sender.backgroundColor = .red
        Questions[index].answer = "first"
        if(Questions[0].answer != "" && Questions[1].answer != "" && Questions[2].answer != "" && Questions[3].answer != "" &&
            Questions[4].answer != ""){
        
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
              if let vc = storyboard.instantiateViewController(identifier: "ThirdViewController") as? ThirdViewController{
              vc.ResultScore = score
              show(vc, sender: nil)
              }
        }
       }
        FirstOption.isEnabled = false
        SecondOption.isEnabled = false
        ThirdOption.isEnabled = false
        FourhOption.isEnabled = false
    }
    
    @IBAction func SecondOption(_ sender: UIButton) {
        if(sender.currentTitle == Questions[index].correct){
            sender.backgroundColor = .green
            Questions[index].answer = Questions[index].correct
            score = score + 1
            if(Questions[0].answer != "" && Questions[1].answer != "" && Questions[2].answer != "" && Questions[3].answer != "" &&
                Questions[4].answer != ""){
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                  if let vc = storyboard.instantiateViewController(identifier: "ThirdViewController") as? ThirdViewController{
                  vc.ResultScore = score
                  show(vc, sender: nil)
                  }
            }
        }else{
            sender.backgroundColor = .red
            Questions[index].answer = "second"
            if(Questions[0].answer != "" && Questions[1].answer != "" && Questions[2].answer != "" && Questions[3].answer != "" &&
                Questions[4].answer != ""){
         
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                  if let vc = storyboard.instantiateViewController(identifier: "ThirdViewController") as? ThirdViewController{
                  vc.ResultScore = score
                  show(vc, sender: nil)
                  }
            }
        }
        FirstOption.isEnabled = false
        SecondOption.isEnabled = false
        ThirdOption.isEnabled = false
        FourhOption.isEnabled = false
    }
    
    @IBAction func ThirdFunction(_ sender: UIButton) {
        if(sender.currentTitle == Questions[index].correct){
            sender.backgroundColor = .green
            Questions[index].answer = Questions[index].correct
            score = score + 1
            if(Questions[0].answer != "" && Questions[1].answer != "" && Questions[2].answer != "" && Questions[3].answer != "" &&
                Questions[4].answer != ""){
         
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                  if let vc = storyboard.instantiateViewController(identifier: "ThirdViewController") as? ThirdViewController{
                  vc.ResultScore = score
                  show(vc, sender: nil)
                  }
            }

        }else{
            sender.backgroundColor = .red
            Questions[index].answer = "third"
            if(Questions[0].answer != "" && Questions[1].answer != "" && Questions[2].answer != "" && Questions[3].answer != "" &&
                Questions[4].answer != ""){
              
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                  if let vc = storyboard.instantiateViewController(identifier: "ThirdViewController") as? ThirdViewController{
                  vc.ResultScore = score
                  show(vc, sender: nil)
                  }
            }

        }
        FirstOption.isEnabled = false
        SecondOption.isEnabled = false
        ThirdOption.isEnabled = false
        FourhOption.isEnabled = false
        
    }
    
    @IBAction func FourthOption(_ sender: UIButton) {
        if(sender.currentTitle == Questions[index].correct){
            sender.backgroundColor = .green
            Questions[index].answer = Questions[index].correct
            score = score + 1
            if(Questions[0].answer != "" && Questions[1].answer != "" && Questions[2].answer != "" && Questions[3].answer != "" &&
                Questions[4].answer != ""){
      
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                  if let vc = storyboard.instantiateViewController(identifier: "ThirdViewController") as? ThirdViewController{
                  vc.ResultScore = score
                  show(vc, sender: nil)
                  }
            }

        }else{
            sender.backgroundColor = .red
            Questions[index].answer = "fourth"
            if(Questions[0].answer != "" && Questions[1].answer != "" && Questions[2].answer != "" && Questions[3].answer != "" &&
                Questions[4].answer != ""){
            
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                  if let vc = storyboard.instantiateViewController(identifier: "ThirdViewController") as? ThirdViewController{
                  vc.ResultScore = score
                  show(vc, sender: nil)
                  }
            }
	            }
        FirstOption.isEnabled = false
        SecondOption.isEnabled = false
        ThirdOption.isEnabled = false
        FourhOption.isEnabled = false
        
    }
    
    class questions{
        var question: String?
        var firstOption: String?
        var secondOption: String?
        var thirdOption: String?
        var fourthOption: String?
        var correct: String?
        var answer: String?
        
        
        init(question: String, firstOption: String, secondOption: String, thirdOption:String, fourthOption:String, correct:String) {
            self.question = question
            self.firstOption = firstOption
            self.secondOption = secondOption
            self.thirdOption = thirdOption
            self.fourthOption = fourthOption
            self.correct = correct
            self.answer = ""
        }
    }
    
   
    func AppendArray(){
        Questions.append(questions(question: "What is your name?", firstOption: "Alikhan", secondOption: "Arman", thirdOption: "Alisher", fourthOption: "Aibyn", correct: "Alikhan"))
        Questions.append(questions(question: "How old are you?", firstOption: "45", secondOption: "11", thirdOption: "18", fourthOption: "19", correct:"18"))
        Questions.append(questions(question: "What is your university?", firstOption: "Astana IT", secondOption: "KBTU", thirdOption: "NU", fourthOption: "MUIT", correct: "Astana IT"))
        Questions.append(questions(question: "What is your laptop?", firstOption: "Asus", secondOption: "MacBook", thirdOption: "HP", fourthOption: "Xiaomi", correct: "Xiaomi"))
        Questions.append(questions(question: "What is your priority language", firstOption: "Russian", secondOption: "Kazakh", thirdOption: "English", fourthOption: "Chinese", correct: "English"))
    }
    @IBAction func Prev(_ sender: Any) {
        
        if index != 0 {
        index -= 1;
        
            Question.text = Questions[index].question
            FirstOption.setTitle(Questions[index].firstOption, for: .normal)
            SecondOption.setTitle(Questions[index].secondOption, for: .normal)
            ThirdOption.setTitle(Questions[index].thirdOption, for: .normal)
            FourhOption.setTitle(Questions[index].fourthOption, for: .normal)
            
            
            if(FirstOption.currentTitle == Questions[index].answer){
                FirstOption.backgroundColor = .green
        
                
            }else if(Questions[index].answer == "first"){
                FirstOption.backgroundColor = .red
             
                
            }else{
                FirstOption.backgroundColor = .gray
             
            }
            if(SecondOption.currentTitle == Questions[index].answer){
                SecondOption.backgroundColor = .green
             
                
            }else if(Questions[index].answer == "second"){
                SecondOption.backgroundColor = .red
            
                
            }else{
                SecondOption.backgroundColor = .gray
                   }
            if(ThirdOption.currentTitle == Questions[index].answer){
                ThirdOption.backgroundColor = .green
          
                
            }else if(Questions[index].answer == "third"){
                ThirdOption.backgroundColor = .red
         
            }else{
                ThirdOption.backgroundColor = .gray
            }
            if(FourhOption.currentTitle == Questions[index].answer){
                FourhOption.backgroundColor = .green
                
            }else if(Questions[index].answer == "fourth"){
                FourhOption.backgroundColor = .red
                           
            }else{
                FourhOption.backgroundColor = .gray
            
            }
            if(Questions[index].answer == ""){
                FirstOption.isEnabled = true
                SecondOption.isEnabled = true
                ThirdOption.isEnabled = true
                FourhOption.isEnabled = true
                
            }else{
                FirstOption.isEnabled = false
                SecondOption.isEnabled = false
                ThirdOption.isEnabled = false
                FourhOption.isEnabled = false
                
            }
            
        }
        return
        
    }
    
    
    @IBAction func Next(_ sender: Any) {
        if index != 4 {
        index += 1;
        
            Question.text = Questions[index].question
            FirstOption.setTitle(Questions[index].firstOption, for: .normal)
            SecondOption.setTitle(Questions[index].secondOption, for: .normal)
            ThirdOption.setTitle(Questions[index].thirdOption, for: .normal)
            FourhOption.setTitle(Questions[index].fourthOption, for: .normal)
            
            if(FirstOption.currentTitle == Questions[index].answer){
                FirstOption.backgroundColor = .green

                
            }else if(Questions[index].answer == "first"){
                FirstOption.backgroundColor = .red
         
                
            }else{
                FirstOption.backgroundColor = .gray
        
                
            }
            if(SecondOption.currentTitle == Questions[index].answer){
                SecondOption.backgroundColor = .green
        
                
            }else if(Questions[index].answer == "second"){
                SecondOption.backgroundColor = .red
                
            }else{
                SecondOption.backgroundColor = .gray
                      }
            if(ThirdOption.currentTitle == Questions[index].answer){
                ThirdOption.backgroundColor = .green
                
            }else if(Questions[index].answer == "third"){
                ThirdOption.backgroundColor = .red
         
                
            }else{
                ThirdOption.backgroundColor = .gray
                }
            if(FourhOption.currentTitle == Questions[index].answer){
                FourhOption.backgroundColor = .green
            
                
            }else if(Questions[index].answer == "fourth"){
                FourhOption.backgroundColor = .red
         
                
            }else{
                FourhOption.backgroundColor = .gray
            }
            if(Questions[index].answer == ""){
                FirstOption.isEnabled = true
                SecondOption.isEnabled = true
                ThirdOption.isEnabled = true
                FourhOption.isEnabled = true
                
            }else{
                FirstOption.isEnabled = false
                SecondOption.isEnabled = false
                ThirdOption.isEnabled = false
                FourhOption.isEnabled = false
                
            }
            
        }
        return
    }
    
    
   
    
    
    

   
}
